clear all
close all
clc

wavread('Données\ temporelles_Voie1.wav');
